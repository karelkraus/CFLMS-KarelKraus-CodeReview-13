-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Sob 05. pro 2020, 13:21
-- Verze serveru: 10.4.14-MariaDB
-- Verze PHP: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `cr13_karelkraus_bigevents`
--
CREATE DATABASE IF NOT EXISTS `cr13_karelkraus_bigevents` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cr13_karelkraus_bigevents`;

-- --------------------------------------------------------

--
-- Struktura tabulky `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Vypisuji data pro tabulku `events`
--

INSERT INTO `events` (`id`, `name`, `date`, `description`, `image`, `capacity`, `email`, `phone`, `address`, `url`, `type`) VALUES
(1, 'Live Concert', '2021-04-04 20:00:00', 'Finally there will be a live concert with a real people. Maybe.', 'https://cdn.pixabay.com/photo/2015/03/26/10/22/band-691224__340.jpg', 200, 'liveconcert@mail.com', '0993930390', 'Prinz Eugen-Straße 27, 1030 Wien', 'www.liveconcert.com', 'Music'),
(2, 'Movie', '2021-08-14 18:00:00', 'You might be able to go to the cinema and watch movie with other people.', 'https://cdn.pixabay.com/photo/2017/11/24/10/43/admission-2974645__340.jpg', 100, 'cinema@mail.com', '0394003033', 'Wienerbergstraße 11 Wienerberg, 1100 Wien', 'www.cinema.com', 'Movie'),
(3, 'Live Concert 2', '2021-07-01 13:00:00', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2016/11/29/06/17/audience-1867754__340.jpg', 120, 'concert@mail.com', '0398403332', 'Schönbrunner Schloßstraße 47, 1130 Wien', 'www.concert.com', 'Music'),
(4, 'Theater Show', '2021-05-02 20:00:00', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2016/10/27/17/34/chicago-1775878__340.jpg', 200, 'theater@mail.com', '473890302', 'Maria-Theresien-Platz, 1010 Wien', 'www.theater.com', 'Theater'),
(5, 'Football Match', '2021-03-07 15:00:00', 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2015/01/21/00/56/football-606235__340.jpg', 2000, 'football@mail.com', '383902020303', 'Erzherzog-Karl-Straße 108, 1220 Wien', 'www.football.com', 'Sport'),
(6, 'Another Movie', '2021-09-11 16:30:00', 'At vero eos et accusam et justo duo dolores et ea rebum.', 'https://cdn.pixabay.com/photo/2017/04/29/11/35/movie-2270554__340.png', 120, 'movie@mail.com', '9482003404', 'Fleischmarkt 6, 1010 Wien', 'www.cinema.com', 'Movie'),
(7, 'Still Singing', '2021-06-11 11:15:00', 'At vero eos et accusam et justo duo dolores et ea rebum.', 'https://cdn.pixabay.com/photo/2017/09/02/18/52/musician-2708190__340.jpg', 1000, 'concert@mail.com', '3892379201', 'Rockhgasse 6, 1010 Wien', 'www.concert.com', 'Music'),
(8, 'Live Theater', '2021-08-07 19:00:00', 'Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'https://cdn.pixabay.com/photo/2014/02/05/00/37/staging-258631__340.jpg', 400, 'theater@mail.com', '9344992031', 'Wehlistraße 66, 1200 Wien', 'www.theater.com', 'Theater'),
(9, 'Tennis Game', '2021-10-16 12:30:00', 'Tennis yes, At vero eos et accusam et justo duo dolores et ea rebum.', 'https://cdn.pixabay.com/photo/2020/11/27/18/59/tennis-5782695__340.jpg', 1200, 'tennis@mail.com', '39301034910', 'Hasenauerstraße Türkenschanzpark, 1180 Wien', 'www.tennis.com', 'Sport'),
(10, 'Super Movie', '2021-05-30 19:00:00', 'Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'https://cdn.pixabay.com/photo/2015/03/26/09/43/camera-690163__340.jpg', 250, 'cinema@mail.com', '49294024042', 'Landstraßer Hauptstraße 2a Wien Mitte, 1030 Wien', 'www.cinema.com', 'Movie'),
(11, 'Hockey Game', '2021-09-29 14:00:00', 'Lets play some hockey. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2018/03/08/21/34/hockey-game-3209935__340.jpg', 1000, 'hockey@mail.com', '949204042', 'Olympiapl. 2, 1020 Wien', 'www.hockey.com', 'Sport'),
(12, 'Theater Again', '2021-02-12 19:00:00', 'Show must go on. At vero eos et accusam et justo duo dolores et ea rebum.', 'https://cdn.pixabay.com/photo/2016/05/06/17/06/ballet-1376250__340.jpg', 400, 'theater@mail.com', '8492030232', 'Opernring 2, 1010 Wien', 'www.theater.com', 'Theater'),
(13, 'Sing Sing', '2021-01-15 17:00:00', 'Singing again. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor.', 'https://cdn.pixabay.com/photo/2016/11/23/15/48/audience-1853662__340.jpg', 400, 'concert@mail.com', '4929400232', 'Kreuzherrengasse 1, 1040 Wien', 'www.concert.com', 'Music'),
(14, 'Golf Mastership', '2021-06-27 13:00:00', 'Golf is a sport too. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2015/05/28/10/12/golf-787826__340.jpg', 1000, 'golf@mail.com', '8429042024', 'Schönbrunner Schloßstraße 47, 1130 Wien', 'www.golf.com', 'Sport'),
(15, 'Movie Movie', '2020-05-03 17:00:00', 'One more movie. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2016/08/16/17/32/hollywood-sign-1598473__340.jpg', 120, 'cinema@mail.com', '3824940204', 'Friedrich-Schmidt-Platz 1, 1010 Wien', 'www.cinema.com', 'Movie'),
(16, 'More Theater', '2021-03-09 18:00:00', 'Theater is good. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2014/08/29/05/00/dance-430554__340.jpg', 240, 'theater@mail.com', '4294025052', 'Maria-Theresien-Platz, 1010 Wien', 'www.theater.com', 'Theater'),
(17, 'Swimming Cup', '2021-05-30 14:00:00', 'Swimming is fun. At vero eos et accusam et justo duo dolores et ea rebum.', 'https://cdn.pixabay.com/photo/2014/08/20/14/56/woman-422546__340.jpg', 300, 'swimming@mail.com', '4929420402', 'Schloss Schönbrunn, 1130 Wien', 'www.swimming.com', 'Sport'),
(18, 'Maestro Concerto', '2021-08-24 18:20:00', 'Best concerto ever. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2016/11/19/09/57/classical-music-1838390__340.jpg', 400, 'concert@mail.com', '9924949242', 'Prinz Eugen-Straße 27, 1030 Wien', 'www.concert.com', 'Music'),
(19, 'Shakespear Theater', '2021-10-03 17:00:00', 'You will not regret. Lorem ipsum dolor sit amet, consetetur sadipscing elitr.', 'https://cdn.pixabay.com/photo/2013/02/26/01/10/auditorium-86197__340.jpg', 500, 'theater@mail.com', '324942004', 'Albertinaplatz 1, 1010 Wien', 'www.theater.com', 'Theater'),
(20, 'Movie Night', '2021-06-11 18:00:00', 'Some good movie to watch. kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.', 'https://cdn.pixabay.com/photo/2013/03/02/02/41/alley-89197__340.jpg', 120, 'movie@mail.com', '39942040024', 'Michaelerkuppel, 1010 Wien', 'www.movie.com', 'Movie');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
