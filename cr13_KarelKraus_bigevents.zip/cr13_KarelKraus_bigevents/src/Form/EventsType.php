<?php

namespace App\Form;

use App\Entity\Events;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class EventsType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name')
            ->add('date')
            ->add('description')
            ->add('image')
            ->add('capacity')
            ->add('email')
            ->add('phone')
            ->add('address')
            ->add('url')
            ->add('type', ChoiceType::class, array ( 'choices' => array ( 'Music' => 'Music' , 'Sport' => 'Sport' , 'Theater' => 'Theater' , 'Movie' => 'Movie' )))
        ;
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Events::class,
        ]);
    }
}
